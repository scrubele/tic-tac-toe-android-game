package com.example.tto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.tto.MainActivity;

public class Score extends MainActivity {
String P1;
int P2;
    int scr1= getScore1();
    int scr2= getScore2();

   // String scor1 = String.valueOf(scr1);
  //  String scor2 = String.valueOf(scr2);

    /*public void setcrc1(int v){
        scr1=v;
    }
    public void setcrc2(int v){
        scr2=v;
    }*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        TextView TextViewScore1 = (TextView) findViewById(R.id.score_1);
        TextView TextViewScore2 = (TextView) findViewById(R.id.score_2);

        String scor1=getIntent().getStringExtra("SCORE1");
        String scor2=getIntent().getStringExtra("SCORE2");

        TextViewScore1.setText(scor1);
        TextViewScore2.setText(scor2);

    }

    public void home(View view){

        Intent intent = new Intent(getApplicationContext(), Home.class);
        startActivity(intent);
    }
}